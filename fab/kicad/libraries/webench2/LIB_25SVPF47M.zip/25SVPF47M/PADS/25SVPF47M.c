*PADS-LIBRARY-SCH-DECALS-V9*

25SVPF47M      32000 32000 100 10 100 10 4 6 0 2 24
TIMESTAMP 2018.01.18.07.52.22
"Default Font"
"Default Font"
350   250   0 24 100 10 "Default Font"
REF-DES
350   150   0 24 100 10 "Default Font"
PART-TYPE
250   -150  0 28 100 10 "Default Font"
*
250   -250  0 28 100 10 "Default Font"
*
CLOSED 5 10 0 -1
200   100  
200   -100 
230   -100 
230   100  
200   100  
COPCLS 5 10 0 -1
300   100  
300   -100 
270   -100 
270   100  
300   100  
OPEN   2 10 0 -1
180   50   
140   50   
OPEN   2 10 0 -1
160   70   
160   30   
OPEN   2 10 0 -1
100   0    
200   0    
OPEN   2 10 0 -1
300   0    
400   0    
T0     0     0 0 0     10    0 0 0     -10   0 32 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T500   0     0 2 0     10    0 0 0     -10   0 32 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*
